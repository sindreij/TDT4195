#include <stdio.h>   
#include <string.h>
#include <iostream>
#include <vector>

#include "bmp.h"
#include "gl/glut.h" 


using namespace std;

const int scale=100;

typedef struct point
{
float x;
float y;
}point;

typedef struct object {
    char type; // 1 is circle, 2 is triangle and 3 is square
    point center;
    float radius;
    point * corners;
} object;

vector<object> objects;

vector<object> getObjectsFromFile(char * filename);

void drawFloor()
{
	unsigned char *grass=read_bmp("input.bmp");
         
 
    glEnable(GL_TEXTURE_2D);
     
    glBindTexture(GL_TEXTURE_2D, 1);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glTexImage2D(GL_TEXTURE_2D, 0, 1, 100,100, 0, GL_RED, GL_UNSIGNED_BYTE,grass);
       
    glBindTexture(GL_TEXTURE_2D,1);

	glBegin(GL_QUADS);
		
		glColor3f(1.0, 1.0, 1.0);

		glTexCoord2d(0,0);
		glVertex3f(0, 0,0);

		glTexCoord2d(0,1);
		glVertex3f(0, 1,0);

		glTexCoord2d(1,1);
		glVertex3f(1, 1,0);

		glTexCoord2d(1,0);
		glVertex3f(1,0,0);

	glEnd();

	glDisable(GL_TEXTURE_2D);
}

void Render()
{    
  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  
  glMatrixMode(GL_MODELVIEW); 
  glLoadIdentity();
	
  glScalef(scale,scale,scale);
  glTranslatef(-0.5,-0.5,0.0);
  drawFloor();
  glTranslatef(0,1,0.0);
  glRotatef(-90,0,0,1);
  
  //TODO: Write your code here to draw 3D objects over 2D bitmap image

  glutSwapBuffers(); 
}

//-----------------------------------------------------------

void Resize(int w, int h)
{ 
  
  if (h==0) h=1;
  glViewport(0,0,w,h); 


  glMatrixMode(GL_PROJECTION); 
  glLoadIdentity();

  glOrtho (-100.0, 100.0, -100.0, 100.0, 100.0,-100.0);
	

}

void Idle()
{

	glutPostRedisplay();
}


void Setup() 
{ 
	objects = getObjectsFromFile("objects.txt");// this function reads the cordinats of objects from the file that you provided in MATLAB...

	glShadeModel (GL_SMOOTH);
	
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);  
	glClearDepth(1);

	glClearColor(0.0f,0.0f,0.0f,1.0f);

}

vector<object> getObjectsFromFile(char * filename) 
{
	FILE * file = fopen(filename,"r");
    if(file==NULL) 
	{
       cout << "Unable to open file " << filename << endl;
        exit(-1);
    }

    vector<object> objects;
	char linec [128];
	string line;
      while ( fgets ( linec, sizeof linec, file ) != NULL ) /* read a line */
      {
		line=string(linec);
        // Split string on spaces
        vector<string> values;
        int pos = line.find(" ");
        while(pos > 0) {
            string value = line.substr(0,pos);
            values.push_back(value);
            line = line.substr(pos+1);
            pos = line.find(" ");
        }
        values.push_back(line);

        object o;
        o.center.x = atof(values[0].c_str());
        o.center.y = atof(values[1].c_str());
        if(values.size() == 3) {
            o.type = 1; // Circle
            o.radius = atof(values[2].c_str());
        } else if(values.size() == 8) {
            o.type = 2; // Triangle
            o.corners = new point[3];
            for(int i = 0; i < 3; i ++) {
                o.corners[i].x = atof(values[i*2+2].c_str());
                o.corners[i].y = atof(values[i*2+3].c_str());
            }
        } else if(values.size() == 10) {
            o.type = 3; // Square
            o.corners = new point[4];
            for(int i = 0; i < 4; i ++) {
                o.corners[i].x = atof(values[i*2+2].c_str());
                o.corners[i].y = atof(values[i*2+3].c_str());
            }
        } else {
            cout << "Error: wrong number of attributes in file" << endl;
        }
        objects.push_back(o);
    }
      fclose ( file );

    return objects;
}