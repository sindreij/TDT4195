% Load image

% Remove noise

% Retrieve objects in image (hint: bwlabel)

% Initialize the result data structure
data(1).center = [0.0 0.0]; % centroid
data(1).attributes = [0]; % radius or corner positions
% a circle will only have one attribute (The radius) 
% the triangle should have 3 corners with x and y coordinates
% the square should have 4 corners with x and y coordinates
% Example for a triangle:
% data(i).attributes = [0.7578, 0.8203; 0.8906, 0.6367; 0.6758, 0.6094];

% For each object

    % Find contour (hint: bwboundaries)
    
    % Calculate centroid (hint: centroid = average position of each pixel 
    % on the contour)
    
    % Find corners (if any) (hint: look at the contour signature which is
    % the length from the centroid)
    
    % If no corners, assume shape is a circle and store radius instead
    
    % Store result in the data list
    
% End for each object

writeAttributesToFile('result.txt', data);
